<?php
include("koneksi.php");

$nomorbus = $_POST['nomorbus'];
$nomorpolisi = $_POST['nomorpolisi'];
$jumlahbangku = $_POST['jumlahbangku'];
$trayek = $_POST['trayek'];

$sql = "INSERT INTO busku (nomorbus, nomorpolisi, jumlahbangku, trayek) VALUES ('$nomorbus', '$nomorpolisi', '$jumlahbangku', '$trayek')";
$simpan = mysqli_query($koneksi, $sql);

if ($simpan) {
    header("location: busku.php");
} else {
    echo "Error: " . mysqli_error($koneksi);
}
?>
