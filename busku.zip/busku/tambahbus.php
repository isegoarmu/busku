<html> 
    
    <head> 
    <title>Tambah Bus</title> 
        <?php include("layout/header.php"); ?>
        <link rel="shortcut icon" href="img/ligerasihombing.png">
        <link rel="stylesheet" href="tambah.css"> 
    </head> 
    
    <body> 
        
    <div class="container">
          <form action="simpanbus.php" method="POST">
             <a href="simpanbus.php">Tambah Menu Bus</a>


               <div class="image">
                    <div class="forom-box">
                         <div class="forom">
                              <h2>Tambah Menu Bus</h2>
                              <div class="input-box"> 
                         <label >NOMOR BUS</label>
                            <input type="text" class="form-control" name="nomorbus"> 
                        </div> 
                        <div class="input-box"> 
                         <label>NOMOR POLISI</label>
                        <input type="text"  class="form-control" name="nomorpolisi"> 
                    </div> 
                    <div class="input-box"> 
                         <label >JUMLAH BANGKU</label>
                            <input type="text" class="form-control" name="jumlahbangku">
                    </div> 
                    <div class="input-box"> 
                         <label>TRAYEK</label>
                        <input type="text" class="form-control" name="trayek"> 
                    </div> 
                    <button type="submit" class="btn btn-primary">Simpan</button> 
                    </form> 
                </div> 
            </div> 
        </div> 
    <br> 
    </form> 
    <?php include("layout/bottom.php");?> 
    </body> 
    </html>