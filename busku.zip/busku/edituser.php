<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="shortcut icon" href="img/ligerasihombing.png">
    <link rel="stylesheet" href="editdaftar.css">
    <?php include("layout/header.php"); ?>
</head>
<style>
    /* CSS styles here */
    button[type="submit"] {
        padding: 10px 20px;
        border-radius: 4px;
        background-color: #989898;
        color: #fff;
        border: none;
        cursor: pointer;
        font-size: 14px;
        transition: background-color 0.3s;
    }

    button[type="submit"]:hover {
        background-color: #FF0000;
    }
</style>

<body>
    <?php
    include('koneksi.php');

    if (isset($_GET['x'])) {
        $namalengkap = $_GET['x'];

        // Retrieve the user data based on the given ID
        $query = "SELECT * FROM daftar WHERE namalengkap = '$namalengkap'";
        $result = mysqli_query($koneksi, $query);
        $data = mysqli_fetch_assoc($result);

        if (!$data) {
            echo "<h3>Data user not found!</h3>";
            exit;
        }
    } else {
        echo "<h3>Invalid user!</h3>";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve the updated data from the form
        $namalengkap = $_POST['namalengkap'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Update the user data in the database
        $query = "UPDATE daftar SET namalengkap='$namalengkap', email='$email', password='$password' WHERE namalengkap='$namalengkap'";
        $updateResult = mysqli_query($koneksi, $query);

        if ($updateResult) {
            echo "<h3>User data updated successfully!</h3>";
        } else {
            echo "<h3>Error updating user data: " . mysqli_error($koneksi) . "</h3>";
        }
    }
    ?>

    <div class="container">
        <form action="" method="POST">
            <div class="image">
                <div class="forom-box">
                    <div class="forom">
                        <h2>Edit User</h2><br><br>

                        <div class="input-box">
                            <label>NAMA LENGKAP</label>
                            <input type="text" name="namalengkap" value="<?php echo $data['namalengkap']; ?>">
                        </div>

                        <div class="input-box">
                            <label>EMAIL</label>
                            <input type="text" name="email" value="<?php echo $data['email']; ?>">
                        </div>

                        <div class="input-box">
                            <label>PASSWORD</label>
                            <input type="text" name="password" value="<?php echo $data['password']; ?>">
                        </div>

                        <button type="submit">Update</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <?php include("layout/bottom.php"); ?>
</body>

</html>
