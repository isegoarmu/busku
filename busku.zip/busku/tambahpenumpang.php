<html> 
    
    <head> 
    <title>TAMBAH PENUMPANG</title>
    <link rel="stylesheet" href="penumpang.css"> 
    <link rel="shortcut icon" href="img/ligerasihombing.png">
        <?php include("layout/header.php"); ?> 
    </head> 
    <body> 
    <div class="container">
          <form action="simpanpenumpang.php" method="POST">
             <a href="simpanpenumpang.php">Tambah Menu Penumpang</a>
    

             <div class="image">
                    <div class="forom-box">
                         <div class="forom">
                              <h2>Tambah Menu Bus</h2>
                              <div class="input-box"> 
                         <label >IDENTITAS (KTP)</label>
                            <input type="text" class="form-control" name="identitas"> 
                        </div> 
                        <div class="input-box"> 
                         <label>TUJUAN</label>
                        <input type="text" class="form-control" name="tujuan"> 
                    </div> 
                   
                    <button type="submit" class="btn btn-primary">Simpan</button> 
                    </form> 
                </div> 
            </div> 
        </div> 
    <br> 
    </form> 
    <?php include("layout/bottom.php");?> 
    </body> 
    </html>