<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     $namalengkap = $_POST['namalengkap'];
$email = $_POST['email'];
$password = $_POST['password'];


    // Validasi data (misalnya validasi email, validasi kekuatan password, dll.)

    // Melakukan koneksi ke database
    $koneksi = mysqli_connect("localhost", "root", "", "bus");

    // Memeriksa koneksi
    if (!$koneksi) {
        die("Koneksi database gagal: " . mysqli_connect_error());
    }

    // Menyimpan data ke dalam tabel pengguna
    $query = "INSERT INTO daftar (namalengkap, email, password) VALUES ('$namalengkap', '$email', '$password')";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<h3>Pendaftaran berhasil!</h3>";
    } else {
        echo "<h3>Error: " . mysqli_error($koneksi) . "</h3>";
    }

    // Menutup koneksi
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Daftar</title>
     <link rel="stylesheet" href="daftar.css">
     <link rel="shortcut icon" href="img/ligerasihombing.png">
</head>

<body>
               
          <div class="container">
          <form action="daftar.php" method="POST">
             <a href="daftar.php">Daftar</a>


               <div class="image">
                    <div class="forom-box">
                         <div class="forom">
                              <h2>Daftar</h2>
                        
                         <div class="input-box"> 
                         <label for="namalengkap">Nama Lengkap</label>
                         <input type="text" name="namalengkap" required>



                              
                              </div>
                         <div class="input-box" >
                         <label for="email">Email</label>
                         <input type="email" name="email" required>
                              
                              
                              </div>
                         <div class="input-box">
                         <label for="passowrd">password</label>
                         <input type="password" name="password" required>
                              </div>
                         <div class="group">
                              <a href="login.php">Silahkan</a>
                              <a href="login.php">Daftar</a>
                              </div>
                              <input type="submit" value="Daftar">
                    </div>
               </div>
          </div>
     </div> 
</body>
</html>