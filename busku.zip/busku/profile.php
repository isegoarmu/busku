<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="shortcut icon" href="img/sihombing.jpg">
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    
<div class="box">
    <div class="content">
    <img src="img/sihombing.jpg" >
    <h2>Ligera Sihombing <br> <span>Disgnner</span></h2>
    <a href="#">Ligera </a>
    </div>
    </div>
</body>
</html>