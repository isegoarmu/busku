<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data id yang di kirim dari url
$nomorbus = $_GET['x'];
 
 
// menghapus data dari database
mysqli_query($koneksi,"delete from busku where nomorbus='$nomorbus'");
 
// mengalihkan halaman kembali ke index.php
header("location:busku.php");
 
?>