<?php
$host = "localhost"; 
$user = "root"; 
$password = "";
$database = "bus";


$koneksi = mysqli_connect($host, $user, $password, $database);


if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KONEKSI</title>
    <link rel="shortcut icon" href="img/sihombing.jpg" >
</head>
<body>
    </div>
</body>
</html>