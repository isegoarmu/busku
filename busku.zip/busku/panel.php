<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Montserrat Font -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="panel.css">
    
    <link rel="shortcut icon" href="img/sihombing.jpg">
  </head>
  <body>
    <div class="grid-container">

      <!-- Header -->
      <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
   
      </header>
      <!-- End Header -->

      <!-- Sidebar -->
      <aside id="sidebar">
        <div class="sidebar-title">
          <div class="sidebar-brand">
            <span class="material-symbols-outlined">BUS</span>
          </div>
          <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
          <li class="sidebar-list-item">
            <a href="index.php" target="_blank">
              <span class="material-icons-outlined">dashboard</span> Dashboard
            </a>
          </li>
          <li class="sidebar-list-item">
            <a href="busku.php" target="_blank">
            <span class="material-symbols-outlined">directions_bus</span>Bus
            </a>
          </li>
          <li class="sidebar-list-item">
            <a href="cetakbus.php" target="_blank">
            <span class="material-symbols-outlined">print</span> Cetak Bus
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="penumpang.php" target="_blank">
            <span class="material-symbols-outlined">account_circle</span>Penumpang
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="tiket.php" target="_blank">
            <span class="material-symbols-outlined">receipt_long</span> Tiket
            </a>
          </li>

          <li class="sidebar-list-item">
            <a href="cetak.php" target="_blank">
            <span class="material-symbols-outlined">print</span> Cetak Tiket
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="user.php" target="_blank">
            <span class="material-symbols-outlined">supervised_user_circle</span> Pengguna
            </a>
          </li>
          <li class="sidebar-list-item">
            <a href="contact.php" target="_blank">
            <span class="material-symbols-outlined">contact_mail</span> Message
            </a>
          </li>
          <li class="sidebar-list-item">
            <a href="#" target="_blank">
              <span class="material-icons-outlined">settings</span> Settings
            </a>
          </li>
          
          <li class="sidebar-list-item">
            <a href="login.php" target="_blank">
            <span class="material-symbols-outlined">login</span> Logout
            </a>
          </li>
        </ul>
      </aside>
      
      <!-- Main -->
      <main class="main-container">
        <div class="main-title">
          <p class="font-weight-bold">DASHBOARD</p>
        </div>

        <div class="main-cards">

          <div class="card">
            <div class="card-inner">
              <p class="text-primary">Tiket</p>
              <span class="material-symbols-outlined text-blue">local_activity</span>
            </div>
            <span class="text-primary font-weight-bold">+99</span>
          </div>

          <div class="card">
            <div class="card-inner">
              <p class="text-primary">Penumpang</p>
              <span class="material-symbols-outlined text-orange">account_circle</span>
            </div>
            <span class="text-primary font-weight-bold">+99</span>
          </div>

          <div class="card">
            <div class="card-inner">
              <p class="text-primary">PETUGAS</p>
              <span class="material-symbols-outlined text-blue">settings_accessibility</span>
            </div>
            <span class="text-primary font-weight-bold">1</span>
          </div>

          <div class="card">
            <div class="card-inner">
              <p class="text-primary">NOTIFIKASI</p>
              <span class="material-symbols-outlined text-red">notifications</span>
            </div>
            <span class="text-primary font-weight-bold">+99</span>
          </div>

        </div>

        <div class="charts">

          <div class="charts-card">
            <p class="chart-title">Tiket</p>
            <div id="bar-chart"></div>
          </div>

          <div class="charts-card">
            <p class="chart-title">Penumpang</p>
            <div id="area-chart"></div>
          </div>

        </div>
      </main>
      <!-- End Main -->

    </div>

    <!-- Scripts -->
    <!-- ApexCharts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.35.3/apexcharts.min.js"></script>
    <!-- Custom JS -->
    <script src="panel.js"></script>
  </body>
</html> 