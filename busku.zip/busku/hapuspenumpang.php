<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data id yang di kirim dari url
$identitas = $_GET['x'];

// Use prepared statement to prevent SQL injection
$stmt = $koneksi->prepare("DELETE FROM penumpang WHERE identitas = ?");
$stmt->bind_param('s', $identitas);
$stmt->execute();

// Check if deletion was successful
if ($stmt->affected_rows > 0) {
    // Redirect to penumpang.php
    header("Location: penumpang.php");
    exit();
} else {
    // Handle deletion error, display an error message or redirect to an error page
    echo "Error deleting the record.";
}
?>
