<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="shortcut icon" href="img/ligerasihombing.png">
    <link rel="stylesheet" href="about.css">
</head>
<body>

    <div class="container__cards">

        <div class="card">
            <div class="cover">
                <img src="img/bus1.jpg" alt="">
                <div class="img__back"></div>
            </div>
            <div class="description">
                <h2>PO.BINTANG UTARA</h2>
                <p>Berawal dari angkutan Kota di sekitar Tapanuli Utara – Sumatera Utara yang di rintis oleh Alm. MT.Sibarani sejak tahun lima puluhan. Pernah bergabung dengan Martumbang, kemudian GOT (Gabungan Otobus Tapanuli), selanjutnya Cito. Sejak Tahun 1968 Bintang Utara berkembang menjadi sebuah jasa pelayanan transportasi antar kota dalam propinsi yang melayani jurusan Medan-Sibolga, Medan-Padang Sidempuan, Medan-Penyabungan. Pada Tahun 1984 seiring dengan semakin meningkatnya kebutuhan masyarakat atas layanan jasa transportasi Bintang Utara mulai melakukan perluasan layanannya menjadi jasa bus antar kota antar propinsi dan kemudian diperluas lagi menjadi antar antar propinsi, khsususnya jaur transportasi Pangkalan Brandan – Medan – Dumai  dan Pekanbaru..</p>
                <input type="button" value="Submit">
            </div>
        </div>

        <div class="card">
            <div class="cover">
                <img src="img/bus2.jpg" alt="">
                <div class="img__back"></div>
            </div>
            <div class="description">
                <h2>PO.BINTANG UTARA</h2>
                <p>Semakin tingginya dukungan dan kepercayaan masyarakat terhadap layanan yang diberikan kepada Bintang Utara pada tahun 2009, Bintang Utara membuka cabang baru di Pangkalan Berandan dan Tanjung Balai..</p>
                <input type="button" value="Submit">
            </div>
        </div>

        <div class="card">
            <div class="cover">
                <img src="img/bus2.jpg" alt="">
                <div class="img__back"></div>
            </div>
            <div class="description">
                <h2>PO.BINTANG UTARA</h2>
                <p>Dengan awalnya bermodalkan 8 bus merk Chevrold buatan Amerika dengan mesin depan dan berkepala, maka trayek-trayek tersebut diatas dijalankan. Bukan hanya itu , selang beberapa tahun berikutnya trayeknya bertambah dengan diikutinya pertambahan amada bus dengan perubahan besar yaitu keluarnya bus merk Mercedes Benz keluaran Jerman yang tidak berkepala dan bermesin belakang yang menjadi cikal bakal armada bus-bus era baru Bintang Utara sampai dengan sekarang.

                Mulanya Perusahaan keluarga ini berbentuk CV yang terus mengalami perubahan menjadi Badan Usaha atau Perseroan Terbatas..</p>
                <input type="button" value="Submit">
            </div>
        </div>

    </div>
    
</body>
</html>