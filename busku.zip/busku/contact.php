<?php
include 'koneksi.php';
  if (isset($_POST["submit"])) {
  $username = $_POST["name"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$judul = $_POST["message"];


    $sql = "INSERT INTO contact (username, email, phone, judul) VALUES ('$username', '$email', '$phone', '$judul')";
$simpan = mysqli_query($koneksi, $sql);

    if ($email) {
      echo "<script>alert('Pesan terkirim.');</script>";
    }else {
      echo "<script>alert('Pesan gagal terkirim.');</script>";
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact</title>
    <link rel="stylesheet" href="contact.css" />
    <link rel="shortcut icon" href="img/ligerasihombing.png">
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="container">
      <div class="form">
        <div class="contact-info">
          <h3 class="title">PO.BUS BINTANG UTARA</h3>
          <p class="text">
            Jika ada kendala segera hubungi kontak person di bawah ini :
          </p>

          <div class="info">
            <div class="information">
              <img src="img/location.png" class="icon" alt="" />
              <p>Jl. Sisingamangaraja No.3, Harjosari I, Kec. Medan Amplas, Kota Medan, Sumatera Utara 20147, Indonesia</p>
            </div>
            <div class="information">
              <img src="img/email.png" class="icon" alt="" />
              <p>po.bintangutara@example.com</p>
            </div>
            <div class="information">
              <img src="img/phone.png" class="icon" alt="" />
              <p>+62(061) 7862146</p>
            </div>
          </div>

          <div class="social-media">
            <p>Media Sosial :</p>
            <div class="social-icons">
              <a href="#">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="#">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="#">
                <i class="fab  fa-whatsapp"></i>
              </a>
              <a href="#">
                <i class="fab fa-youtube"></i>
              </a>
              <a href="#">
                <i class="fa fa-bus"></i>
              </a>
            </div>
          </div>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form action="" method="post" autocomplete="off">
            <h3 class="title">Contact</h3>
            <div class="input-container">
              <input type="text" name="name" class="input" />
              <label for="">Nama Lengkap</label>
              <span>Username</span>
            </div>
            <div class="input-container">
              <input type="email" name="email" class="input" />
              <label for="">Email</label>
              <span>Email</span>
            </div>
            <div class="input-container">
              <input type="tel" name="phone" class="input" />
              <label for="">+62 (061) 7862146</label>
              <span>Phone</span>
            </div>
            <div class="input-container textarea">
              <textarea name="message" class="input"></textarea>
              <label for="">Kirim Pesan</label>
              <span>Message</span>
            </div>
            <input type="submit" name="submit" value="Send" class="btn" />
          </form>
        </div>
      </div>
    </div>

    <script src="contact.js"></script>
  </body>
</html>
