<!doctype html>
<html lang="en">
<head>
    <title>Halaman Menu</title>
    
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="shortcut icon" href="img/ligerasihombing.png">
    
</head>
<body>
  <h2>CETAK DATA BUS</h2>
  
</form>
<table border = "2" cellspacing="0" width="100%">
<tr>
            <th>NOMOR BUS</th>
            <th>NOMOR POLISI</th>
            <th>JUMLAH BANGKU</th>
            <th>TRAYEK</th>
            
        </tr>
        <?php
       
include('koneksi.php'); 
if(isset($_GET['cari'])){
    $pencarian = $_GET['cari'];
    $query = "SELECT * FROM busku WHERE nomorbus LIKE '%".$pencarian."%'";
} else {
    $query = "SELECT * FROM busku";
}

$tampil = mysqli_query($koneksi, $query);
while($data = mysqli_fetch_array($tampil)){
            ?>
            <tr>
                <td><?php echo $data['nomorbus']; ?></td>
                <td><?php echo $data['nomorpolisi']; ?></td>
                <td><?php echo $data['jumlahbangku']; ?></td>
                <td><?php echo $data['trayek']; ?></td>
                
            </tr>
            <?php
            
        }
        ?>
        
  
    </table>
    <?php include("layout/bottom.php"); ?>
    
<script type="text/javascript">
    window.print();
</script>
</body>
</html>
