<!doctype html>
<html lang="en">
<head>
    <title>PRINT TIKET</title>
    <link rel="icon" href="img/sihombing.jpg" />
    
</head>
<body>
  <h2>CETAK DATA TIKET</h2>
</form>
<table border = "2" cellspacing="0" width="100%">
<tr>
            <th>KODE TUJUAN</th>
            <th>NOMOR BANGKU</th>
            <th>TUJUAN</th>
            <th>HARGA TIKET</th>
            <th>JUMLAH PENUMPANG</th>
            <th>TOTAL</th>
        </tr>
        <?php
       
include('koneksi.php'); 
if(isset($_GET['cari'])){
    $pencarian = $_GET['cari'];
    $query = "SELECT * FROM tiket WHERE kodetujuan LIKE '%".$pencarian."%'";
} else {
    $query = "SELECT * FROM tiket";
}

$tampil = mysqli_query($koneksi, $query);
while($data = mysqli_fetch_array($tampil)){
            ?>
            <tr>
                <td><?php echo $data['kodetujuan']; ?></td>
                <td><?php echo $data['nomorbangku']; ?></td>
                <td><?php echo $data['tujuan']; ?></td>
                <td><?php echo $data['hargatiket']; ?></td>
                <td><?php echo $data['jumlahpenumpang']; ?></td>
                <td><?php echo $data['total']; ?></td>
            </tr>
            <?php
            
        }
        ?>
        
  
    </table>
    <?php include("layout/bottom.php"); ?>
    
<script type="text/javascript">
    window.print();
</script>
</body>
</html>
