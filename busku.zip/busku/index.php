<!DOCTYPE html>
<html>
<head>
	<title>PO.BINTANG UTARA</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/sihombing.jpg" >
</head>
<body>
<header>
	<nav>
		<div class="logo">
		<span>PO.BINTANG UTARA</span>
		</div>
		<div class="menu">
			<a href="#">Home</a>
			<a href="#">About</a>
			<a href="#">Gallery</a>
			<a href="contact.php">Contact</a>
            <a href="panel.php">Admin</a>
		</div>
		<div class="icon">
			<a href="login.php">Keluar</a>

		</div>
	</nav>


	<section class="h-text">
		<h1 data-aos="zoom-in-down" data-aos-delay="100">PO.BINTANG UTARA.</h1><br><br>
		<p data-aos="zoom-in-down" width="100px">PO Bintang Utara Putra merupakan salah satu perusahaan otobus legendaris asal Medan, Sumatera Utara. PO bus ini menjadi moda transportasi andalan masyarakat Medan yang ingin bepergian ke kota-kota lainnya di Sumatera Utara dan sekitarnya.

PO Bintang Utara Putra didirikan oleh MT (Maruli Taronggal) Sibarani pada 1968, yang diawali dari pengusaha tekstil hingga bisa membeli angkutan kota (angkot) yang dioperasikan oleh keluarganya yang tidak bekerja saat itu.

Tujuan utama terjun dalam dunia transportasi adalah untuk memberi kemudahan kepada masyarakat dalam bepergian dari satu wilayah ke wilayah lain. Kini, PO Bintang Utara Putra dipimpin oleh generasi kedua, yaitu sang putra, Washington Sibarani.</p>

<button data-aos="zoom-in-down" data-aos-delay="100"> <a href="#"></a>Bus</button>
	</section>
</header>

<section class="filter-gallery">
	<div class="portfolio-menu">
			<ul>
				<li class="active" data-filter="*"> Galery</li>
			</ul>
		</div>
		<div class="portfolio-item">
			<div class="item web"  data-aos="flip-left" data-aos-offset="200" data-aos-delay="100">
				<img src="img/bus.jpg" width="500" height="500">
			</div>

			<div class="item seo"  data-aos="flip-left" data-aos-offset="200" data-aos-delay="200">
				<img src="img/busku.png" width="500" height="500">
			</div>
			<div class="item graphics"  data-aos="flip-left" data-aos-offset="100" data-aos-delay="300">
				<img src="img/bus2.jpg" width="500" height="500">
			</div>
            <div class="item web"  data-aos="flip-left" data-aos-offset="100" data-aos-delay="400">
				<img src="img/bus3.jpg" width="500" height="500">
			</div>

			<div class="item seo"  data-aos="flip-left" data-aos-offset="100" data-aos-delay="500">
				<img src="img/bus4.jpg" width="500" height="500">
			</div>
			<div class="item graphics"  data-aos="flip-left" data-aos-offset="100" data-aos-delay="600">
				<img src="img/bus5.jpg" width="500" height="500">
			</div>
		</div>
	
</section>


<!--- filter gallery end---->

<!-- slider start--->

<section class="members">
		<div class="member-info"  data-aos="zoom-in-up" data-aos-offset="100" data-aos-delay="100">
            <h1><span>Informasi</span></h1>
        
             <br> <span><h2>OWNER.LIGERA SIHOMBING*</h2></span></br>


</div>


<div class="member-card"  data-aos="zoom-in-down" data-aos-offset="100" data-aos-delay="300">
	

	<img src="img/ligerasihombing.png">
    <p>
    Transportasi darat untuk penumpang lainnya, Transportasi darat untuk penumpang dalam perkotaan dan pinggiran kota
	</p>

</div>

</section>





<footer>
	


	<div class="f-contact" data-aos="zoom-in-up" data-aos-offset="200">
		<div>
			<h1>Informasi</h1>
			<p>PO.BINTANG UTARA</p>
			
			<i class="fa fa-whatsapp"></i>
			<i class="fa fa-instagram"></i>
			<i class="fa fa-telegram"></i>
			<i class="fa fa-twitter"></i>
		</div>


		<div>
			<h1>Menu</h1>
			<p>About us</p>
			<p>Gallery</p>
			<p>Admin</p>
			<p>Login</p>

		</div>

		<div>
			<h1>Admin</h1>
			<p>Daftar</p>
			<p>Bus</p>
			<p>Tiket</p>
			<p>Pelanggan</p>

		</div>

		<div>
			<h1>Help & Support</h1>
			<p>Privacy policy</p>
			<p>Term & conditions</p>
			<p>Technical Bus</p>
			<p>Customer </p>

		</div>
	</div>
</footer>













<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>
<script>
	$('.portfolio-item').isotope({
  // options
  itemSelector: '.item',
  layoutMode: 'fitRows'
});
		$('.portfolio-menu ul li').click(function(){
		$('.portfolio-menu ul li').removeClass('active');
		$(this).addClass('active');

			var selector = $(this).attr('data-filter');
		$('.portfolio-item').isotope({
			filter:selector
		});
		return false;
	});
</script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();

</script>
</body>
</html>