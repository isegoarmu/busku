<html> 
    
    <head> 
    <title>TAMBAH MENU TIKET</title> 
    <link rel="stylesheet" href="tiket.css">
    <link rel="shortcut icon" href="img/ligerasihombing.png">
        <?php include("layout/header.php"); ?> 
    </head> 

    <body> 
    <div class="container">
          <form action="simpantiket.php" method="POST">
             <a href="simpantiket.php">Tambah Menu Tiket</a>


               <div class="image">
                    <div class="forom-box">
                         <div class="forom">
                              <h2>Tambah Tiket</h2>
   
                              <div class="input-box"> 
                         <label >KODE TUJUAN</label>
                        <input type="text" class="form-control" name="kodetujuan"> 
                    </div> 
                    <div class="input-box"> 
                         <label >NOMOR BANGKU</label>
                            <input type="text" class="form-control" name="nomorbangku">
                        </div>
                     
                        <div class="input-box"> 
                         <label >TUJUAN</label>
                        <input type="text" class="form-control" name="tujuan"> 
                    </div> 
                    
                    <div class="input-box"> 
                         <label >HARGA TIKET</label>
                        <input type="text" class="form-control" name="hargatiket"> 
                    </div> 

                    
                    <div class="input-box"> 
                         <label >JUMLAH PENUMPANG</label>
                        <input type="text" class="form-control" name="jumlahpenumpang"> 
                    </div> 

                    
                    <div class="input-box"> 
                         <label >TOTAL</label>
                        <input type="text" class="form-control" name="total"> 
                    </div> 
                    <button type="submit" class="btn btn-primary">Simpan</button> 
                    </form> 
                </div> 
            </div> 
        </div> 
    <br> 
    </form> 
    <?php include("layout/bottom.php");?> 
    </body> 
    </html>