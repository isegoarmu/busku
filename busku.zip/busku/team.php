<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Team</title>
    <link rel="stylesheet" href="team.css">
</head>
<body>
    <div class="container">
        <div class="icon">
        <div class="imgBx active" style="--i:1;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:2;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:3;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:4;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:5;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:6;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:7;">
        <img src="img/sihombing.jpg">
        </div>
        <div class="imgBx" style="--i:8;">
        <img src="img/sihombing.jpg">
        </div>
        </div>
        <div class="content">
            <div class="contentBX active" id="content1">
                <div class="card">
                    <div class="imgBx">
                        <img src="img/sihombing.jpg" >
                    </div> 
                <div class="textBX">
                    <h2>Ligera Sihombing <br> <span>Website Bus</span></h2>
                    <ul class="sci">
                        <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-whatsapp"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
                    </ul>
                </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</body>
</html>