<?php
include("koneksi.php");

// Validate and sanitize user input
$identitas = isset($_POST['identitas']) ? $_POST['identitas'] : '';
$tujuan = isset($_POST['tujuan']) ? $_POST['tujuan'] : '';

// Perform form validation and handle errors
if (empty($identitas) || empty($tujuan)) {
    echo "Please fill in all the required fields.";
    exit; // Stop further execution
}

// Sanitize user input (optional)
$identitas = mysqli_real_escape_string($koneksi, $identitas);
$tujuan = mysqli_real_escape_string($koneksi, $tujuan);

// Prepare and execute the SQL query using prepared statements
$sql = "INSERT INTO penumpang (identitas, tujuan) VALUES (?, ?)";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "ss", $identitas, $tujuan);
$proses = mysqli_stmt_execute($stmt);

// Check if the query execution was successful
if ($proses) {
    header("location: penumpang.php");
    exit;
} else {
    echo "Error: " . mysqli_error($koneksi);
    exit; // Stop further execution
}
?>
