<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Penumpang</title>
    <link rel="shortcut icon" href="img/sihombing.jpg" type="image/x-icon">
    <link rel="stylesheet" href="editpenumpang.css">
    <?php include("layout/header.php"); ?>
</head>
<style>
        
        .input-box {
            position: relative;
            margin-bottom: 20px;
        }
        
        .input-box label {
            position: absolute;
            top: -20px;
            left: 0;
            color: #fff;
            font-size: 14px;
        }
        
        .input-box input {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: none;
            outline: none;
            background-color: #eee;
            font-size: 14px;
            color: #333;
        }
        
        button[type="submit"] {
            padding: 10px 20px;
            border-radius: 4px;
            background-color: #989898;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        
        button[type="submit"]:hover {
            background-color: #FF0000;
        }
            </style>
<body>

    <?php
    include('koneksi.php');

    if (isset($_GET['x'])) {
        $identitas = $_GET['x'];

        // Retrieve the bus data based on the given ID
        $query = "SELECT * FROM penumpang WHERE identitas = '$identitas'";
        $result = mysqli_query($koneksi, $query);
        $data = mysqli_fetch_assoc($result);

        if (!$data) {
            echo "<h3>Data penumpang not found!</h3>";
            exit;
        }
    } else {
        echo "<h3>Invalid Penumpang!</h3>";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve the updated data from the form
        $identitas = $_POST['identitas'];
        $tujuan = $_POST['tujuan'];

        // Update the bus data in the database
        $query = "UPDATE penumpang SET tujuan='$tujuan' WHERE identitas='$identitas'";
        $updateResult = mysqli_query($koneksi, $query);

        if ($updateResult) {
            echo "<h3>Bus data updated successfully!</h3>";
        } else {
            echo "<h3>Error updating bus data: " . mysqli_error($koneksi) . "</h3>";
        }
    }
    ?>

        
    <div class="container">
<form action="" method="POST">

        <div class="image">
            <div class="forom-box">
                <div class="forom">
                    <h2>Edit Penumpang</h2><br><br>

                    <div class="input-box">
                        <label>IDENTITAS (KTP)</label>
                        <input type="text" name="identitas" value="<?php echo $data['identitas']; ?>">
                        </div>
                        
                        <div class="input-box">
                        <label>TUJUAN</label>
                        <input type="text" name="tujuan" value="<?php echo $data['tujuan']; ?>">
                        </div>
       
        <button type="submit">Update</button>
    </form>

    <?php include("layout/bottom.php"); ?>
    <script src="jqueri.js"></script>
</body>

</html>
