<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Bus Tiket</title>
    <link rel="shortcut icon" href="img/sihombing.jpg" type="image/x-icon">
    <link rel="stylesheet" href="tiket.css">
    <?php include("layout/header.php"); ?>
</head>
<style>
        
        .input-box {
            position: relative;
            margin-bottom: 20px;
        }
        
        .input-box label {
            position: absolute;
            top: -20px;
            left: 0;
            color: #fff;
            font-size: 14px;
        }
        
        .input-box input {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: none;
            outline: none;
            background-color: #eee;
            font-size: 14px;
            color: #333;
        }
        
        button[type="submit"] {
            padding: 10px 20px;
            border-radius: 4px;
            background-color: #989898;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        
        button[type="submit"]:hover {
            background-color: #FF0000;
        }
            </style>
<body>

    <?php
    include('koneksi.php');

    if (isset($_GET['x'])) {
        $kodetujuan = $_GET['x'];

        // Retrieve the bus data based on the given ID
        $query = "SELECT * FROM tiket WHERE kodetujuan = '$kodetujuan'";
        $result = mysqli_query($koneksi, $query);
        $data = mysqli_fetch_assoc($result);

        if (!$data) {
            echo "<h3>Data tiket not found!</h3>";
            exit;
        }
    } else {
        echo "<h3>Invalid Tiket!</h3>";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve the updated data from the form
        $kodetujuan = $_POST['kodetujuan'];
        $nomorbangku = $_POST['nomorbangku'];
        $tujuan = $_POST['tujuan'];
        $hargatiket = $_POST['hargatiket'];
        $jumlahpenumpang = $_POST['jumlahpenumpang'];
        $total = $_POST['total'];

        // Update the bus data in the database
        $sql = "UPDATE tiket SET kodetujuan='$kodetujuan', nomorbangku='$nomorbangku', tujuan='$tujuan', hargatiket='$hargatiket', jumlahpenumpang='$jumlahpenumpang', total='$total' WHERE kodetujuan='$kodetujuan'";
        $updateResult = mysqli_query($koneksi, $sql);

        if ($updateResult) {
            echo "<h3>Bus data updated successfully!</h3>";
        } else {
            echo "<h3>Error updating bus data: " . mysqli_error($koneksi) . "</h3>";
        }
    }
    ?>

    <div class="container">
        <form action="" method="POST">
            <div class="image">
                <div class="forom-box">
                    <div class="forom"><br><br>
                        <h2>Edit Bus Tiket</h2><br><br>
                        <div class="input-box">
                            <label>KODE TUJUAN</label>
                            <input type="text" name="kodetujuan" value="<?php echo $data['kodetujuan']; ?>">
                        </div>

                        <div class="input-box">
                            <label>NOMOR BANGKU</label>
                            <input type="text" name="nomorbangku" value="<?php echo $data['nomorbangku']; ?>">
                        </div>

                        <div class="input-box">
                            <label>TUJUAN</label>
                            <input type="text" name="tujuan" value="<?php echo $data['tujuan']; ?>">
                        </div>

                        <div class="input-box">
                            <label>HARGA TIKET</label>
                            <input type="text" name="hargatiket" value="<?php echo $data['hargatiket']; ?>">
                        </div>

                        <div class="input-box">
                            <label>JUMLAH PENUMPANG</label>
                            <input type="text" name="jumlahpenumpang" value="<?php echo $data['jumlahpenumpang']; ?>">
                        </div>

                        <div class="input-box">
                            <label>Total</label>
                            <input type="text" name="total" value="<?php echo $data['total']; ?>">
                        </div>

                        <button type="submit">Update</button>
                    </div>
                </div>
            </div>
        </form>

        <?php include("layout/bottom.php"); ?>
        <script src="jqueri.js"></script>
    </div>
</body>

</html>
