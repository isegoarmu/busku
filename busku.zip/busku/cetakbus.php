<!doctype html>
<html lang="en">
<head>
    <title>Halaman Menu</title>
    <link rel="shortcut icon" href="img/ligerasihombing.png">
   
</head>
<body>
   

   
<h1>CETAK DATA BUS</h1>
<button><a target="_blank" href="cetak.php">Cetak</a></button>     
</form>
<table border = "2" cellspacing="0" width="100%">
<tr>
            <th>NOMOR BUS</th>
            <th>NOMOR POLISI</th>
            <th>JUMLAH BANGKU</th>
            <th>TRAYEK</th>
        </tr>
        <?php
       
include('koneksi.php'); 
if(isset($_GET['cari'])){
    $pencarian = $_GET['cari'];
    $query = "SELECT * FROM busku WHERE nomorbus LIKE '%".$pencarian."%'";
} else {
    $query = "SELECT * FROM busku";
}

$tampil = mysqli_query($koneksi, $query);
while($data = mysqli_fetch_array($tampil)){
            ?>
            <tr>
                <td><?php echo $data['nomorbus']; ?></td>
                <td><?php echo $data['nomorpolisi']; ?></td>
                <td><?php echo $data['jumlahbangku']; ?></td>
                <td><?php echo $data['trayek']; ?></td>
                
            </tr>
            <?php
            
        }
        ?>
        
  
    </table>
    <?php include("layout/bottom.php"); ?>
</body>
