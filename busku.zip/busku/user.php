<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="shortcut icon" href="img/sihombing.jpg" >
    <title>User</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
        background-color: #f1f1f1;
    }

    h1 {
        text-align: center;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        margin-bottom: 20px;
    }

    th, td {
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: #333;
        color: #fff;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    .neon-button {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background-color: #000000;
        color: #fff;
        font-size: 10px;
        text-decoration: none;
        text-transform: uppercase;
        box-shadow: 0 0 16px #000000, 0 0 10px ;
        animation: animate 1s infinite;
    }

    @keyframes animate {
        0% {
            box-shadow: 0 0 16px #FF007B, 0 0 10px  #FF0000;
        }
        100% {
            box-shadow: 0 0 16px #FF0000, 0 0 10px #FF0000;
        }
    }

    .edit-button, .delete-button {
        padding: 5px;
        border: none;
        background-color: transparent;
        cursor: pointer;
    }

    .edit-button span, .delete-button span, .print-button span {
        font-family: 'Material Symbols Outlined', sans-serif;
        font-size: 20px;
    }
    input[type="text"] {
        padding: 5px;
        width: 200px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
    }

    button[type="submit"] {
        padding: 5px 10px;
        border: none;
        border-radius: 4px;
        background-color: #00c3ff;
        color: #fff;
        font-size: 14px;
        cursor: pointer;
    }
    
    
    .pagination {
            list-style: none;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 10px; /* Adjust the value to your preference */
        }

        .page-item {
            margin: 0 5px;
        }

        .page-link {
            display: inline-block;
            padding: 5px 10px;
            text-decoration: none;
            color: #333;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .page-link:hover {
            background-color: #e0e0e0;
        }

        .page-link.active {
            background-color: #333;
            color: #fff;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
</style>
    </style>
</head>

<body>
 
    
<form >
    <div class="top-bar">
        <a href="daftar.php" class="neon-button">Tambah Menu Pengguna</a>
        <div>
            <input type="text" name="cari" value="<?php if (isset($_GET['cari'])) { echo $_GET['cari']; } ?>" placeholder="Pencarian">
            <button type="submit">Cari</button>
        </div>
    </div>
    </form>
<br>
    <br>

    <table border="2" cellspacing="0" width="100%">
        <tr>
            <th>NAMA LENGKAP</th>
            <th>EMAIL</th>
            <th>PASSWORD</th>
            <th>Opsi</th>
        </tr>
        <?php
        include('koneksi.php');
        if (isset($_GET['cari'])) {
            $pencarian = $_GET['cari'];
            $query = "SELECT * FROM daftar WHERE namalengkap LIKE '%" . $pencarian . "%'";
        } else {
            $query = "SELECT * FROM daftar";
        }

        $tampil = mysqli_query($koneksi, $query);
        while ($data = mysqli_fetch_array($tampil)) {
        ?>
           

            <tr>
                <td><?php echo $data['namalengkap']; ?></td>
                <td><?php echo $data['email']; ?></td>
                <td><?php echo $data['password']; ?></td>
                <td>
                    <a href="edituser.php?x=<?php echo $data['namalengkap']; ?>">
                        <button class="edit-button">
                            <span class="material-symbols-outlined">edit</span>
                        </button>
                    </a>   
                    <a href="hapusdaftar.php?x=<?php echo $data['namalengkap']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?');">
                        <button class="delete-button">
                            <span class="material-symbols-outlined">auto_delete</span>
                        </button>
                    </a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
    <?php
$totalPages = 5; // Replace this with the actual number of pages

// Get the current page number from the URL query string
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;

// Generate the pagination links
echo '<ul class="pagination" style="justify-content: flex-end;">'; // Added inline style to align to the right
echo '<li class="page-item"><a class="page-link" href="panel.php">Pilih</a></li>';

for ($i = 1; $i <= $totalPages; $i++) {
    // Add the active class to the current page link
    $activeClass = ($i == $current_page) ? 'active' : '';
    echo '<li class="page-item ' . $activeClass . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
}

echo '<li class="page-item"><a class="page-link" href="panel.php">Selanjutnya</a></li>';
echo '</ul>';
?>
    <?php include("layout/bottom.php"); ?>
</body>

</html>
