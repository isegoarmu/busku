<?php
include("koneksi.php");

$kodetujuan = $_POST['kodetujuan'];
$nomorbangku = $_POST['nomorbangku'];
$tujuan = $_POST['tujuan'];
$hargatiket = $_POST['hargatiket'];
$jumlahpenumpang = $_POST['jumlahpenumpang'];
$total = $_POST['total'];

$sql = "INSERT INTO tiket (kodetujuan, nomorbangku, tujuan, hargatiket, jumlahpenumpang,total) VALUES ('$kodetujuan', '$nomorbangku', '$tujuan', '$hargatiket','$jumlahpenumpang','$total')";
$simpan = mysqli_query($koneksi, $sql);

if ($simpan) {
    header("location: tiket.php");
} else {
    echo "Error: " . mysqli_error($koneksi);
}
?>
